"use client";

import { motion } from "framer-motion";
import { getFailureClass } from "@/lib/failure-classes";

// Muted, warm-friendly accent per class for the light theme.
const ACCENT: Record<number, string> = {
  1: "#2b8fb3",
  2: "#3f6fd6",
  3: "#c98a2b",
  4: "#8a5bc0",
};

/**
 * The solution card that appears once a beat's problem has been read.
 *
 * Different entrance than the original: it flips down into place like a
 * stamp hitting a ledger page (rotateX from -70deg to flat) rather than
 * sliding in from the right.
 */
export default function StoryClassCard({ classId }: { classId: 1 | 2 | 3 | 4 }) {
  const copy = getFailureClass(classId);
  const accent = ACCENT[classId];

  return (
    <div style={{ perspective: 900 }}>
      <motion.div
        initial={{ opacity: 0, rotateX: -70, y: -12 }}
        whileInView={{ opacity: 1, rotateX: 0, y: 0 }}
        viewport={{ once: true, margin: "-15% 0px -15% 0px" }}
        transition={{ duration: 0.55, ease: [0.16, 1, 0.3, 1] }}
        style={{ transformOrigin: "top center" }}
        className="mt-8 max-w-md rounded-2xl border border-black/10 bg-white/70 p-6 shadow-[0_20px_50px_-24px_rgba(60,50,40,0.4)] backdrop-blur"
      >
        <div className="flex items-center gap-2">
          <span className="h-2.5 w-2.5 rounded-full" style={{ background: accent }} />
          <span
            className="font-mono text-[11px] uppercase tracking-[0.22em]"
            style={{ color: accent }}
          >
            {copy.tag}
          </span>
        </div>

        <h3 className="story-display mt-3 text-2xl">{copy.title}</h3>

        <p className="mt-3 text-sm leading-relaxed text-muted">{copy.problem}</p>
        <div className="mt-4 rounded-xl p-4" style={{ background: "rgba(233,217,207,0.4)" }}>
          <p
            className="font-mono text-[10px] uppercase tracking-[0.2em]"
            style={{ color: "var(--color-clay)" }}
          >
            Agent recovery
          </p>
          <p className="mt-1.5 text-sm leading-relaxed text-fg">{copy.rescue}</p>
        </div>
      </motion.div>
    </div>
  );
}

"use client";

import { useRef, useState } from "react";
import {
  motion,
  useMotionValueEvent,
  useScroll,
  useTransform,
} from "framer-motion";
import { STORY } from "@/lib/story";
import Meena from "./Meena";
import StoryCard from "./StoryCard";

/**
 * Scroll-linked narrative — deck-of-receipts version.
 *
 * Instead of a single doodle weaving along an S-curve while beats scroll past
 * it, this version pins a compact stage: Meena stands fixed on the left and
 * "stamps" in fresh with a little spring pop each time the beat changes,
 * while the beats themselves live in a card stack on the right — the active
 * card flat and centred, read cards fanned up behind it, the next card
 * waiting tilted just below. A thin bar across the top fills like a receipt
 * feeding through a printer, tracking progress through the whole story.
 */
export default function StoryScene() {
  const sceneRef = useRef<HTMLElement>(null);
  const [active, setActive] = useState(0);
  const activeRef = useRef(0);
  const segments = STORY.length - 1;

  const { scrollYProgress } = useScroll({
    target: sceneRef,
    offset: ["start start", "end end"],
  });

  useMotionValueEvent(scrollYProgress, "change", (p) => {
    const idx = Math.max(0, Math.min(segments, Math.round(p * segments)));
    if (idx !== activeRef.current) {
      activeRef.current = idx;
      setActive(idx);
    }
  });

  const beat = STORY[active];
  const printBarScale = useTransform(scrollYProgress, (p) => p);

  return (
    <section
      ref={sceneRef}
      className="relative"
      style={{ height: `${STORY.length * 120}vh` }}
    >
      <div className="sticky top-0 flex h-screen flex-col overflow-hidden">
        {/* Ink bar — feeds across the top like a receipt printer, tracking
            progress through the whole story (a different progress motif
            than the original's drawn curve behind the character). */}
        <div className="relative h-[3px] w-full bg-black/10">
          <motion.div
            style={{ scaleX: printBarScale, background: "var(--color-clay)" }}
            className="h-full w-full origin-left"
          />
        </div>

        <div className="relative flex flex-1 items-center gap-10 px-6 md:px-16">
          {/* Meena — pinned in place, pops in fresh per beat like a stamp
              hitting paper, instead of gliding side to side. */}
          <div className="relative hidden h-[46vh] w-[30%] shrink-0 items-end justify-center md:flex">
            <motion.span
              key={beat.id}
              initial={{ scale: 0.55, opacity: 0.55 }}
              animate={{ scale: 1.5, opacity: 0 }}
              transition={{ duration: 0.8, ease: "easeOut" }}
              className="pointer-events-none absolute inset-0 m-auto h-[70%] w-[70%] rounded-full border-2"
              style={{ borderColor: "rgba(204,120,92,0.5)" }}
            />
            <motion.div
              key={`${beat.id}-figure`}
              initial={{ opacity: 0, scale: 1.4, rotate: -10 }}
              animate={{ opacity: 1, scale: 1, rotate: 0 }}
              transition={{ type: "spring", stiffness: 260, damping: 18 }}
              className="relative h-full w-full"
            >
              <Meena pose={beat.pose} />
            </motion.div>
          </div>

          {/* The stacked deck of beats */}
          <div className="relative h-[60vh] flex-1">
            {STORY.map((b, i) => (
              <StoryCard
                key={b.id}
                beat={b}
                index={i}
                progress={scrollYProgress}
                segments={segments}
                isLast={i === STORY.length - 1}
              />
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}

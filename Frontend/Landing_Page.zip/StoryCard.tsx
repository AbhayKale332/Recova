"use client";

import Link from "next/link";
import { motion, useTransform, type MotionValue } from "framer-motion";
import type { StoryBeat } from "@/lib/story";
import SpeechCloud from "./SpeechCloud";
import StoryClassCard from "./StoryClassCard";

type Props = {
  beat: StoryBeat;
  index: number;
  /** 0..1 progress across the whole pinned scroll track. */
  progress: MotionValue<number>;
  /** STORY.length - 1 */
  segments: number;
  isLast: boolean;
};

/**
 * One card in the deck. Instead of sliding in from a side, cards live in a
 * stack: the active one sits flat and centred, cards already "read" get
 * pushed up into a fanned discard pile behind it, and the next one waits,
 * tilted, just below the fold — like receipts being pulled off a spike one
 * at a time.
 */
export default function StoryCard({ beat, index, progress, segments, isLast }: Props) {
  // How many "beats" away this card is from the currently centred one.
  // Negative = already passed (stacks up and back), positive = still to come.
  const distance = useTransform(progress, (p) => p * segments - index);

  const y = useTransform(distance, [-1, -0.4, 0, 0.4, 1], [-64, -18, 0, 46, 240]);
  const scale = useTransform(distance, [-1, -0.4, 0, 0.4, 1], [0.82, 0.95, 1, 0.94, 0.86]);
  const rotate = useTransform(distance, [-1, -0.4, 0, 0.4, 1], [-7, -2, 0, 3, 7]);
  const opacity = useTransform(distance, [-1.15, -0.5, 0, 0.5, 1], [0.28, 0.85, 1, 0.7, 0]);
  const zIndex = useTransform(distance, (d) => Math.round(100 - Math.abs(d) * 10));

  return (
    <motion.div
      style={{ y, scale, rotate, opacity, zIndex }}
      className="story-card absolute inset-x-0 mx-auto w-full max-w-md rounded-3xl border border-black/10 bg-[#fbf9f3] p-8 shadow-[0_30px_60px_-20px_rgba(60,50,40,0.35)]"
    >
      <SpeechCloud lines={beat.lines} />
      {beat.classId ? <StoryClassCard classId={beat.classId} /> : null}

      {isLast ? (
        <div className="mt-8 flex flex-wrap items-center gap-4">
          <Link
            href="/console"
            className="inline-flex items-center gap-2 rounded-full px-6 py-3 text-sm font-medium text-white transition-transform hover:scale-[1.03]"
            style={{ background: "var(--color-fg)" }}
          >
            Enter the recovery console
            <span aria-hidden>→</span>
          </Link>
          <span className="font-mono text-[11px] uppercase tracking-[0.2em] text-muted">
            Live batch running now
          </span>
        </div>
      ) : null}
    </motion.div>
  );
}

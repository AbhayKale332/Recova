"use client";

import { motion } from "framer-motion";

/**
 * A hand-drawn speech cloud holding one beat's dialogue lines.
 *
 * Different reveal than the original: instead of fading up, each line
 * "unfurls" top-to-bottom via a clip-path wipe — reads more like a receipt
 * printing out than a caption fading in.
 */
export default function SpeechCloud({ lines }: { lines: string[] }) {
  return (
    <div className="space-y-4">
      {lines.map((line, i) => (
        <motion.p
          key={i}
          initial={{ clipPath: "inset(0 0 100% 0)", opacity: 0.4 }}
          whileInView={{ clipPath: "inset(0 0 0% 0)", opacity: 1 }}
          viewport={{ once: true, margin: "-20% 0px -20% 0px" }}
          transition={{
            duration: 0.55,
            delay: i * 0.2,
            ease: [0.65, 0, 0.35, 1],
          }}
          style={{ transformOrigin: "top" }}
          className="speech-cloud story-display max-w-xl px-6 py-4 text-2xl leading-snug md:text-[1.7rem]"
        >
          {line}
        </motion.p>
      ))}
    </div>
  );
}
